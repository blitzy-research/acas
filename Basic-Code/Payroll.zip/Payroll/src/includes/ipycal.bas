		cal.estimated.ded.amt,\       rem 9/24/79
		cal.low.income.exempt(01),cal.low.income.exempt(02),\
		cal.low.income.exempt(03),cal.low.income.exempt(04),\
		cal.standard.deduction(01),cal.standard.deduction(02),\
		cal.standard.deduction(03),cal.standard.deduction(04),\
		cal.tax.credit(01,1),cal.tax.credit(01,2),\
		cal.tax.credit(02,1),cal.tax.credit(02,2),\
		cal.tax.credit(03,1),cal.tax.credit(03,2),\
		cal.tax.credit(04,1),cal.tax.credit(04,2),\
		cal.tax.credit(05,1),cal.tax.credit(05,2),\
		cal.tax.credit(06,1),cal.tax.credit(06,2),\
		cal.tax.credit(07,1),cal.tax.credit(07,2),\
		cal.tax.credit(08,1),cal.tax.credit(08,2),\
		cal.tax.credit(09,1),cal.tax.credit(09,2),\
		cal.tax.credit(10,1),cal.tax.credit(10,2)

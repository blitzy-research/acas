		ckh.emp.no$,\		rem   9/18/79
		ckh.from.date$,\
		ckh.to.date$,\
		ckh.check.no$,\
		ckh.amt(01),ckh.amt(02),ckh.amt(03),ckh.amt(04),\
		ckh.amt(05),ckh.amt(06),ckh.amt(07),ckh.amt(08),\
		ckh.amt(09),ckh.amt(10),ckh.amt(11),ckh.amt(12),\
		ckh.amt(13),ckh.amt(14),ckh.amt(15),ckh.amt(16)

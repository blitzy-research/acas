		act.no$,\	     rem 12/11/79
		act.desc$

dim ckh.amt			(pr1.max.chk.cats%)    rem 9/29/79

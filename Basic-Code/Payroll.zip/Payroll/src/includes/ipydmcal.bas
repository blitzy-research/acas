dim cal.low.income.exempt	(04)	  rem  09/29/79
dim cal.standard.deduction	(04)
dim cal.tax.credit		(10,02)

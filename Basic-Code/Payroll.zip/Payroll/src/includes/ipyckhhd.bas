		ckh.hdr.no.recs%,\	  rem  10/30/79
		ckh.hdr.history.printed%,\
		ckh.hdr.101,\
		ckh.hdr.102,\
		ckh.hdr.201$

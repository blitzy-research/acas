		his.hdr.no.recs%,\	    rem  11/12/79
		his.hdr.last.to.date$,\
		his.hdr.101,\
		his.hdr.102,\
		his.hdr.201$

		pr1.debugging%,\	 rem 12/11/79
		pr1.co.name$,pr1.co.addr1$,pr1.co.addr2$,pr1.co.addr3$,\
		pr1.co.city$,pr1.co.state$,pr1.co.zip$,pr1.co.phone$,\
		pr1.ded.drive%,pr1.gld.drive%, \
		pr1.emp.drive%,pr1.his.drive%,pr1.hrs.drive%,pr1.act.drive%,\
		pr1.glx.drive%,pr1.chk.drive%,pr1.tax.drive%,pr1.pay.drive%,\
		pr1.pyo.drive%,pr1.ckh.drive%,pr1.coh.drive%,pr1.cho.drive%,\
		pr1.offset.cash.acct%,pr1.rate2.factor,pr1.rate3.factor,\
		pr1.rate4.exclusion.type%,pr1.rate.name$(1),\
		pr1.rate.name$(2),pr1.rate.name$(3),pr1.rate.name$(4),\
		pr1.min.wage,pr1.check.printing.used%,pr1.bell.suppressed%,\
		pr1.s.used%,pr1.m.used%,pr1.w.used%,pr1.b.used%,\
		pr1.chk.history.used%, \
		pr1.void.chks.over.max%,pr1.void.check.amt, \
		pr1.leading.crlf%,pr1.console.width.poke.addr%, \
		pr1.jc.used%,pr1.gl.used%,pr1.default.pay.interval$,\
		pr1.default.dist.acct%,pr1.default.pay.rate,\
		pr1.gl.file.suffix$,pr1.default.norm.units,\
		pr1.default.hs.type$,pr1.max.pay.factor,\
		pr1.default.vac.rate,pr1.default.sl.rate,\
		pr1.fed.id$,pr1.state.id$,pr1.local.id$,\
		pr1.date.dy%,pr1.date.mo%,pr1.date.yr%,\
		pr1.lines.per.page%,pr1.page.width%,\
		pr1.user.program.used%,pr1.user.program$,pr1.user.prog.desc$,\
		pr1.dist.used%,\
		pr1.101,pr1.102,pr1.103,pr1.104,pr1.105,\
		pr1.106,pr1.107,pr1.108,pr1.109,pr1.110,\
		pr1.111,pr1.112,pr1.113,pr1.114,pr1.115,\
		pr1.201$,pr1.202$,pr1.203$,pr1.204$,pr1.205$,\
		pr1.206$,pr1.207$,pr1.208$,pr1.209$,pr1.210$

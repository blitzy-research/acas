		act.hdr.no.recs%	 rem   9/12/79

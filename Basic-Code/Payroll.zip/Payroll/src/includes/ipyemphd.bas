		emp.hdr.no.recs%,\	  rem 10/30/79
		emp.hdr.no.del.recs%,\
		emp.hdr.next.del.rec%,\
		emp.hdr.101,\
		emp.hdr.102,\
		emp.hdr.201$

		emp.no$,\		   rem	12/02/79
		emp.status$,emp.hs.type$,emp.pay.interval$,\
		emp.taxing.state$,emp.job.code$,\
		emp.start.date$,emp.birth.date$,emp.term.date$,\
		emp.sex$,emp.marital$,emp.ssn$,\
		emp.pay.freq%,emp.emp.name$,\	  rem last sort field
		emp.next.del%,emp.cur.apply.no%,emp.phone$,\
		emp.addr1$,emp.addr2$,emp.city$,emp.state$,emp.zip$,\
		emp.rate(1),emp.rate(2),emp.rate(3),emp.rate(4),\
		emp.auto.units,emp.normal.units,emp.max.pay,\
		emp.rate4.exclusion%,emp.eic.used%,\
		emp.cal.head.of.house%,emp.cal.ded.allow%,\
		emp.fwt.allow%,emp.swt.allow%,emp.lwt.allow%,\
		emp.pension.used%,emp.bank.acct.no$,\
		emp.fwt.exempt%,emp.swt.exempt%,emp.lwt.exempt%,\
		emp.fica.exempt%,emp.sdi.exempt%,\
		emp.co.futa.exempt%,emp.co.sui.exempt%,\
		emp.sys.exempt%(1),emp.sys.exempt%(2),emp.sys.exempt%(3),\
		emp.sys.exempt%(4),emp.sys.exempt%(5),\
		emp.vac.rate,emp.vac.accum,emp.vac.used,\
		emp.sl.rate,emp.sl.accum,emp.sl.used,\
		emp.comp.accum,emp.comp.used,\
		emp.dist.acct%(1),emp.dist.percent(1),\
		emp.dist.acct%(2),emp.dist.percent(2),\
		emp.dist.acct%(3),emp.dist.percent(3),\
		emp.dist.acct%(4),emp.dist.percent(4),\
		emp.dist.acct%(5),emp.dist.percent(5),\
		emp.ed.desc$(1),emp.ed.factor(1),emp.ed.limit(1),\
		emp.ed.earn.ded$(1),emp.ed.exclusion%(1),\
		emp.ed.amt.percent$(1),emp.ed.limit.used%(1),\
		emp.ed.chk.cat%(1),emp.ed.acct.no%(1), \
		emp.ed.desc$(2),emp.ed.factor(2),emp.ed.limit(2),\
		emp.ed.earn.ded$(2),emp.ed.exclusion%(2),\
		emp.ed.amt.percent$(2),emp.ed.limit.used%(2),\
		emp.ed.chk.cat%(2),emp.ed.acct.no%(2), \
		emp.ed.desc$(3),emp.ed.factor(3),emp.ed.limit(3),\
		emp.ed.earn.ded$(3),emp.ed.exclusion%(3),\
		emp.ed.amt.percent$(3),emp.ed.limit.used%(3),\
		emp.ed.chk.cat%(3),emp.ed.acct.no%(3)


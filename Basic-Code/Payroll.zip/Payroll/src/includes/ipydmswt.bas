dim withhold.deduction.amount(5)	rem 11/12/79
dim withhold.num.entries%(5)
dim withhold.cutoff(pr1.max.swt.entries%,5)
dim withhold.percent(pr1.max.swt.entries%,5)

dim chk.amt		(pr1.max.chk.cats%)	     rem  9/12/79
